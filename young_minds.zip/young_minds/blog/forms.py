from django import forms
from . models import Comment
from crispy_forms.helper import FormHelper

class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ['content']

        widgets = {
          'content': forms.Textarea(attrs={'rows':2, 'cols':50,'class':'responsive-text-area'}),
        }

        labels = {
        "content": ""
    }
