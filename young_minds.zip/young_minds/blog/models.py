from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
from django.urls import reverse
import math
from ckeditor.fields import RichTextField
from ckeditor_uploader.fields import RichTextUploadingField

# Create your models here.
class Category(models.Model):

    category = models.CharField(max_length=100)

    def __str__(self):
        return self.category

    class Meta:
        verbose_name_plural = "categories"

class about_page_details(models.Model):


    user_name = models.CharField(max_length=100,default='')
    role = models.CharField(max_length=100,default='')
    image = models.ImageField(default='default_content.jpg', upload_to='about_page')
    description = models.TextField(max_length=1000,default='')

    def __str__(self):
        return self.user_name

    class Meta:
        verbose_name_plural = "about_page_details"

class carousel_images_messages(models.Model):
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    image = models.ImageField(default='default_content.jpg', upload_to='carousel_images')
    category = models.ForeignKey(Category, on_delete=models.CASCADE ,default='Other')
    message =  models.CharField(max_length=500)
    date_posted = models.DateTimeField(default=timezone.now)
    def __str__(self):
        return '{}'.format("images_800_534_resolution")

    class Meta:
        verbose_name_plural = "carousel_images_messages"

    def when_published(self):
        now = timezone.now()

        diff= now - self.date_posted

        if diff.days == 0 and diff.seconds >= 0 and diff.seconds < 60:
            seconds= diff.seconds

            if seconds == 1:
                return str(seconds) +  "second ago"

            else:
                return str(seconds) + " seconds ago"



        if diff.days == 0 and diff.seconds >= 60 and diff.seconds < 3600:
            minutes= math.floor(diff.seconds/60)

            if minutes == 1:
                return str(minutes) + " minute ago"

            else:
                return str(minutes) + " minutes ago"



        if diff.days == 0 and diff.seconds >= 3600 and diff.seconds < 86400:
            hours= math.floor(diff.seconds/3600)

            if hours == 1:
                return str(hours) + " hour ago"

            else:
                return str(hours) + " hours ago"

        # 1 day to 6 days
        if diff.days >= 1 and diff.days < 6:
            days= diff.days

            if days == 1:
                return str(days) + " day ago"

            else:
                return str(days) + " days ago"

        if diff.days >= 6 :

            return "date"

class No_Of_Views(models.Model):
    post = models.CharField(max_length=100)
    post_title = models.CharField(max_length=100)
    views_count = models.IntegerField(default=0)
    username = models.CharField(max_length=100)

    def __str__(self):
        return '{} counts on "{}"'.format((self.views_count),(self.post_title).title())

    class Meta:
        verbose_name_plural = "No_Of_Views"

class Post(models.Model):
    title = models.CharField(max_length=100)
    category = models.ForeignKey(Category, on_delete=models.CASCADE ,default='Other')
    content = RichTextUploadingField()
    summary = models.CharField(max_length=100,default="Please click to read more")
    date_posted = models.DateTimeField(default=timezone.now)
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    thumbnail = models.ImageField(default='default_content.jpg', upload_to='content_pic')
    image1 = models.ImageField(default='default_content.jpg', upload_to='content_pic')
    image2 = models.ImageField(default='default_content.jpg', upload_to='content_pic')
    image3 = models.ImageField(default='default_content.jpg', upload_to='content_pic')
    likes = models.ManyToManyField(User, related_name="likes", blank=True)

    def __str__(self):
        return self.title

    def total_likes(self):
        return self.likes.count()

    def when_published(self):
        now = timezone.now()

        diff= now - self.date_posted

        if diff.days == 0 and diff.seconds >= 0 and diff.seconds < 60:
            seconds= diff.seconds

            if seconds == 1:
                return str(seconds) +  "second ago"

            else:
                return str(seconds) + " seconds ago"



        if diff.days == 0 and diff.seconds >= 60 and diff.seconds < 3600:
            minutes= math.floor(diff.seconds/60)

            if minutes == 1:
                return str(minutes) + " minute ago"

            else:
                return str(minutes) + " minutes ago"



        if diff.days == 0 and diff.seconds >= 3600 and diff.seconds < 86400:
            hours= math.floor(diff.seconds/3600)

            if hours == 1:
                return str(hours) + " hour ago"

            else:
                return str(hours) + " hours ago"

        # 1 day to 6 days
        if diff.days >= 1 and diff.days < 6:
            days= diff.days

            if days == 1:
                return str(days) + " day ago"

            else:
                return str(days) + " days ago"

        if diff.days >= 6 :

            return "date"

    def get_absolute_url(self):
        return reverse('post-detail', kwargs={'pk':self.pk})

class Comment(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    content = models.TextField(max_length = 200)
    date_commented = models.DateTimeField(auto_now_add=True)
    reply = models.ForeignKey('Comment', null=True, related_name='replies', on_delete=models.CASCADE)

    def __str__(self):
        return '{} commented on blog "{}"'.format((self.user.username).title(),(self.post.title).title())

    def when_commented(self):
        now = timezone.now()

        diff= now - self.date_commented
        print('\n#######\n')
        print(diff.days)
        if diff.days == 0 and diff.seconds >= 0 and diff.seconds < 60:
            seconds= diff.seconds

            if seconds == 1:
                return str(seconds) +  "second ago"

            else:
                return str(seconds) + " seconds ago"



        if diff.days == 0 and diff.seconds >= 60 and diff.seconds < 3600:
            minutes= math.floor(diff.seconds/60)

            if minutes == 1:
                return str(minutes) + " minute ago"

            else:
                return str(minutes) + " minutes ago"



        if diff.days == 0 and diff.seconds >= 3600 and diff.seconds < 86400:
            hours= math.floor(diff.seconds/3600)

            if hours == 1:
                return str(hours) + " hour ago"

            else:
                return str(hours) + " hours ago"

        # 1 day to 6 days
        if diff.days >= 1 and diff.days < 6:
            days= diff.days

            if days == 1:
                return str(days) + " day ago"

            else:
                return str(days) + " days ago"

        if diff.days >= 6 :

            return "date"
