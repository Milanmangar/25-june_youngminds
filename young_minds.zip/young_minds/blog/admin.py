from django.contrib import admin
from .models import Post,Comment,Category,carousel_images_messages,No_Of_Views,about_page_details

# Register your models here.
admin.site.register(Post)
admin.site.register(Comment)
admin.site.register(Category)
admin.site.register(carousel_images_messages)
admin.site.register(No_Of_Views)
admin.site.register(about_page_details)
