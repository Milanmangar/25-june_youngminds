from django.shortcuts import render,get_object_or_404,redirect
from .models import Post,Comment,Category,No_Of_Views,carousel_images_messages,about_page_details
from django.views.generic import ListView,DetailView,CreateView,UpdateView,DeleteView
from django.contrib.auth.mixins import LoginRequiredMixin,UserPassesTestMixin
from django.contrib.auth.models import User
from .forms import CommentForm
from django.template.loader import render_to_string
from django.http import JsonResponse
from django.db.models import Count
from django.db.models import Q
from django.core.mail import send_mail
from django.contrib import messages
# Create your views here.

def home(request):

    context = {"posts":Post.objects.all()}
    return render(request,'blog/home.html',context)
def feedback_email(request):

    if request.method == 'POST':

        send_mail(('username ({})  '.format(request.user.username))+"[ "+request.POST.get('subject')+" ]",
        request.POST.get('feedback_content'),'alphayoungminds@gmail.com',
        ['alphayoungminds@gmail.com'],fail_silently=False)
        messages.success(request,f'Thank you for taking your time out! Your Feeback is very important to us!')
    return redirect("about")
def common_info():

    #for category with count
    categories = Post.objects.values('category__category').order_by('category').annotate(the_count=Count('category'))

    # for popular post with views
    popular_post = No_Of_Views.objects.all().order_by('-views_count')[:5]
    print(popular_post)
    popular_post_list = []
    for post in popular_post:
        single_post = Post.objects.get(pk=post.post)
        popular_post_list.append(single_post)


    result = {"categories":categories,"popular_post":popular_post_list}
    return result


class PostListView(ListView):
    model = Post
    template_name = 'blog/home.html'
    context_object_name = 'posts'
    ordering = ['-date_posted']
    paginate_by = 8

    def get_queryset(self):

        post_list = []

        search = self.request.GET.get('search')

        if search :

            posts_all = Post.objects.filter(Q(author__username__icontains=search) |
            Q(title__icontains=search) |
            Q(content__icontains=search)).order_by("-date_posted")
            for post in posts_all:
                try:
                    views = No_Of_Views.objects.get(post=post.pk)
                    views = views.views_count
                    post.views = views
                except:
                    views = 0
                post_list.append(post)
        else:
            posts_all = Post.objects.all().order_by("-date_posted")
            for post in posts_all:
                try:
                    views = No_Of_Views.objects.get(post=post.pk)
                    views = views.views_count
                    post.views = views
                except:
                    views = 0
                post_list.append(post)

        return post_list

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        response = common_info()
        context['categories'] =  response["categories"]
        context['popular_posts'] =  response["popular_post"]
        context['carousels'] = carousel_images_messages.objects.all()
        context['title'] = "Young Minds"
        '''print(response["categories"])
        print(response["popular_post"])'''


        return context

class UserPostListView(ListView):
    model = Post
    template_name = 'blog/user_posts.html'
    context_object_name = 'posts'
    paginate_by = 8



    def get_queryset(self):

            post_list = []

            search = self.request.GET.get('search')

            if search :

                posts_all = Post.objects.filter(Q(author__username__icontains=search) |
                Q(title__icontains=search) |
                Q(content__icontains=search),Q(author__username__iexact=self.kwargs.get('username'))).order_by("-date_posted")
                for post in posts_all:
                    try:
                        views = No_Of_Views.objects.get(post=post.pk)
                        views = views.views_count
                        post.views = views
                    except:
                        views = 0
                    post_list.append(post)
            else:
                posts_all = Post.objects.filter(author__username__iexact=self.kwargs.get('username')).order_by("-date_posted")

                for post in posts_all:
                    try:
                        views = No_Of_Views.objects.get(post=post.pk)
                        views = views.views_count
                        post.views = views
                    except:
                        views = 0
                    post_list.append(post)

            return post_list


    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        user = self.kwargs.get('username')
        context['title'] = user.title() +"'s Posts"
        response = common_info()
        context['categories'] =  response["categories"]
        context['popular_posts'] =  response["popular_post"]
        context['user_name'] = self.kwargs.get('username')
        return context



class CategoryListView(ListView):
    model = Post
    template_name = 'blog/category_posts.html'
    context_object_name = 'posts'
    paginate_by = 8


    def get_queryset(self):

        post_list = []

        search = self.request.GET.get('search')

        if search :

            posts_all = Post.objects.filter(Q(author__username__icontains=search) |
            Q(title__icontains=search) |
            Q(content__icontains=search),Q(category__category__iexact=self.kwargs.get('category'))).order_by("-date_posted")
            for post in posts_all:
                try:
                    views = No_Of_Views.objects.get(post=post.pk)
                    views = views.views_count
                    post.views = views
                except:
                    views = 0
                post_list.append(post)
        else:
            posts_all = Post.objects.filter(category__category__iexact=self.kwargs.get('category')).order_by("-date_posted")

            for post in posts_all:
                try:
                    views = No_Of_Views.objects.get(post=post.pk)
                    views = views.views_count
                    post.views = views
                except:
                    views = 0
                post_list.append(post)

        return post_list
        '''category = self.kwargs.get('category')
        print(category)
        print(Post.objects.filter(category=category).order_by("-date_posted"))
        return Post.objects.filter(category=category).order_by("-date_posted")'''

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['selected_category'] =  self.kwargs.get('category')
        response = common_info()
        context['categories'] =  response["categories"]
        context['popular_posts'] =  response["popular_post"]
        context['title'] = 'Category-'+ self.kwargs.get('category')
        return context


'''class ActiveUserPostDetailView(ListView):
    model = Post
    template_name = 'blog/user_all_posts.html'
    context_object_name = 'posts'
    paginate_by = 6
    def get_queryset(self):
        return Post.objects.filter(author__username=self.request.user).order_by("-date_posted")

    def get_context_data(self, **kwargs):
        # no of views

        ## ends here
        context = super().get_context_data(**kwargs)
        response = common_info()
        context['categories'] =  response["categories"]
        context['popular_posts'] =  response["popular_post"]

        return context'''


class AboutListView(ListView):
    model = about_page_details
    template_name = 'blog/about.html'
    context_object_name = 'about_makers'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        response = common_info()
        context['categories'] =  response["categories"]

        context['title'] = 'About Page'
        return context





class PostDetailView(DetailView):
    model = Post
    context_object_name = 'post'
    def get_queryset(self):
        return Post.objects.filter(pk=self.kwargs.get('pk')).order_by("-date_posted")

    def get_context_data(self, **kwargs):
        # no of views

        no_of_views = No_Of_Views.objects.filter(post=self.kwargs.get('pk')).exists()

        #RealEstateListing.objects.filter(slug_url=slug).exists()
        if no_of_views:

            no_of_views_count = No_Of_Views.objects.get(post=self.kwargs.get('pk'))
            print(no_of_views_count.username)
            print(self.request.user)
            print(no_of_views_count.views_count)

            if no_of_views_count.username != self.request.user.username:
                no_of_views_save = int(no_of_views_count.views_count) + 1
                no_of_views_count.views_count =  no_of_views_save
                no_of_views_count.save()
            else:
                no_of_views_save = no_of_views_count.views_count

        else:
            post_title = Post.objects.get(pk=self.kwargs.get('pk'))
            print(post_title.title)


            no_of_views_save =  0
            no_of_views_for_post =  No_Of_Views(post=self.kwargs.get('pk'),post_title=post_title.title,username=post_title.author,views_count=no_of_views_save)
            no_of_views_for_post.save()


        ## ends here
        context = super().get_context_data(**kwargs)
        post = Post.objects.filter(pk=self.kwargs.get('pk')).order_by("-date_posted")
        context['comments'] = Comment.objects.filter(post=post[0],reply=None).order_by("-id")

        context['comment_form'] = CommentForm()
        is_liked = False

        if post[0].likes.filter(id=self.request.user.id).exists():
            is_liked = True



        similar_post_pk = Post.objects.filter(pk=self.kwargs.get('pk')).order_by("-date_posted")
        similar_post_pk = similar_post_pk[0]

        similar_post  = Post.objects.filter(category__category__iexact=similar_post_pk.category.category).exclude(pk=self.kwargs.get('pk')).order_by("-date_posted")[:3]
        if len(similar_post) == 0:
            similar_post  = Post.objects.all().exclude(pk=self.kwargs.get('pk')).order_by("-date_posted")[:3]
        context['is_liked'] = is_liked
        context['similar_posts'] = similar_post

        context['views'] = int(no_of_views_save)
        response = common_info()
        context['categories'] =  response["categories"]
        context['popular_posts'] =  response["popular_post"]
        title = (post[0]).title
        context['title'] = title
        #context['total_likes'] = post.total_likes()

        return context
    def post(self, request, *args, **kwargs):
        post = Post.objects.filter(pk=self.kwargs.get('pk')).order_by("-date_posted")
        comment_form = CommentForm(request.POST)
        if comment_form.is_valid():
            content = comment_form.cleaned_data["content"]
            reply_id = self.request.POST.get("comment_id")
            comment_qs = None
            if reply_id:
                comment_qs = Comment.objects.get(id=reply_id)
            comment_form = Comment.objects.create(post=post[0],user=self.request.user,content=content, reply=comment_qs)
            comment_form.save()
            return redirect("post-detail",pk=self.kwargs.get('pk'))



class PostLikeListView():
    model = Post
    template_name = 'blog/likes_list.html'
    context_object_name = 'post'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        response = common_info()
        context['categories'] =  response["categories"]

        context['title'] = 'About Page'
        return context

class PostCreateView(LoginRequiredMixin,CreateView):
    model = Post
    fields = ["title","category","content","thumbnail"]

    def form_valid(self, form):
        form.instance.author = self.request.user
        return super().form_valid(form)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        response = common_info()
        context['categories'] =  response["categories"]

        context['title'] = 'Create Blog'
        return context

class PostUpdateView(LoginRequiredMixin,UserPassesTestMixin,UpdateView):
    model = Post
    fields = ["title","content","image1","image2","image3"]
    def form_valid(self, form):
        form.instance.author = self.request.user
        return super().form_valid(form)

    def test_func(self):
        post = self.get_object()
        if self.request.user == post.author:
            return True
        else:
            return False

class PostDeleteView(LoginRequiredMixin,UserPassesTestMixin,DeleteView):
    model = Post
    success_url = "/"
    def test_func(self):
        post = self.get_object()
        if self.request.user == post.author:
            return True
        else:
            return False

def like_post(request):
    #post = get_object_or_404(Post,id=request.POST.get("post_id"))
    if request.method == 'POST':

        print("\ninside like view\n")
        print("\n in {} \n".format(request.POST.get('id')))
        post = get_object_or_404(Post,id=request.POST.get("id"))

        is_liked = False
        if post.likes.filter(id=request.user.id).exists():
            print("\ninside like\n")
            post.likes.remove(request.user)
            is_liked = False
        else:
            print("\ninside dislike\n")
            post.likes.add(request.user)
            is_liked = True
        comments = Comment.objects.filter(post=post,reply=None).order_by("-id")
        context = {
        "post":post,
        "is_liked":is_liked,
        "comment": comments
        }
        #return redirect("post-detail",pk=request.POST.get("post_id"))
        print("\ngetting in ajax\n")
        if request.is_ajax():
            print("\ninside ajax\n")
            html = render_to_string('blog/likes_section.html', context, request=request)
            return JsonResponse({"form":html})
