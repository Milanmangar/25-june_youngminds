from django.urls import path
from . views import (PostListView,PostDetailView,PostCreateView,PostUpdateView,PostDeleteView,
UserPostListView,like_post,CategoryListView,AboutListView,feedback_email,PostLikeListView)
from . import views

urlpatterns = [
    path('', PostListView.as_view(),name="blog-home"),
    path('post/<int:pk>/', PostDetailView.as_view(),name="post-detail"),
    path('post/new/', PostCreateView.as_view(),name="post-create"),
    path('post/<int:pk>/update/', PostUpdateView.as_view(),name="post-update"),
    path('post/<int:pk>/delete/', PostDeleteView.as_view(),name="post-delete"),
    path('user/<str:username>/', UserPostListView.as_view(),name="user-posts"),
    path('post/<str:category>/', CategoryListView.as_view(),name="category-posts"),
    path('about/', AboutListView.as_view(),name="about"),
    #path('users/myposts/', ActiveUserPostDetailView.as_view(),name="my-blogs"),
    path('feedback-email/', views.feedback_email,name="feedback-email"),
    path('blog/like/', views.like_post,name="like_post"),
    path('blog/likelist/<int:pk>', views.PostLikeListView,name="post-like-list"),


]
