from django.shortcuts import render,redirect
from django.contrib import messages
from .forms import UserRegistrationForm,UserUpdateForm,ProfileUpdateForm
from django.contrib.auth.decorators import login_required
from django.views.generic import ListView
from .models import Profile
from blog.views import *
from django.contrib.auth import authenticate, login
from django.http import JsonResponse

# Create your views here.
def register(request):
    if request.method == "POST":
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')

            new_user = authenticate(username=form.cleaned_data['username'],
                                    password=form.cleaned_data['password1'])
            login(request, new_user)

        p_form = ProfileUpdateForm(request.POST, request.FILES, instance=request.user.profile)
        if form.is_valid():

            if  p_form.is_valid:

                p_form.save()
                messages.success(request,f'Account created! Welcome Young Minds family!')
                return redirect('blog-home')
    else:
        form = UserRegistrationForm()
        form_profile = ProfileUpdateForm()
    response = common_info()
    categories =  response["categories"]
    
    return render(request,"users/registration.html",{"form":form ,"form_profile":form_profile,"categories":categories})

def validate_username(request):
    username = request.GET.get('username', None)
    data = {
        'is_taken': User.objects.filter(username__iexact=username).exists()
    }
    if data['is_taken']:
        data['error_message'] = 'A user with this username "{}" already exists !'.format(username)

        return JsonResponse(data)

    email = request.GET.get('email', None)
    if email != "":
        data = {
            'is_taken': User.objects.filter(email__iexact=email).exists()
        }
        if data['is_taken']:
            data['error_message'] = '"{}" email id is already registered!'.format(email)
        return JsonResponse(data)



'''@login_required
def profile(request):

    user_post = Post.objects.filter(author__username=request.user)
    context = {}
    response = common_info()
    context["user_posts"] = user_post
    context['categories'] =  response["categories"]
    context['popular_posts'] =  response["popular_post"]

    return render(request,"users/profile.html",context)'''

class ProfileListView(ListView):
    model = Post
    template_name = 'users/profile.html'
    context_object_name = 'user_posts'
    ordering = ['-date_posted']
    paginate_by = 5

    def get_queryset(self):
        return Post.objects.filter(author__username=self.kwargs.get('username'))

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        response = common_info()
        context['categories'] =  response["categories"]
        context['popular_posts'] =  response["popular_post"]
        user = self.kwargs.get('username')
        context["description"] = Profile.objects.get(user__username__iexact=self.kwargs.get('username'))
        context['title'] = user.title() +"'s Profile"
        return context

@login_required
def profile_update(request):
    if request.method == 'POST':
        u_form = UserUpdateForm(request.POST, instance=request.user)
        p_form = ProfileUpdateForm(request.POST, request.FILES, instance=request.user.profile)
        if u_form.is_valid and p_form.is_valid:
            u_form.save()
            p_form.save()
            messages.success(request,f'Your account has been updated successfully!.')
            return redirect('profile' ,request.user)

    else:
        u_form = UserUpdateForm(instance=request.user)
        p_form = ProfileUpdateForm(instance=request.user.profile)
    response = common_info()
    categories =  response["categories"]
    context = {"u_form":u_form,"p_form":p_form,"categories":categories,"title":"Update Profile"}
    return render(request,"users/profile_update.html",context)
